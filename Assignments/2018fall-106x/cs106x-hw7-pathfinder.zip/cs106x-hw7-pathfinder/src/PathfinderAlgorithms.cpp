// This is the CPP file you will edit and turn in.
// Also remove these comments here and add your own, along with
// comments on every function and on complex code sections.
// TODO: write comment header for this file; remove this comment

#include "PathfinderAlgorithms.h"
// TODO: include any other headers you need; remove this comment

using namespace std;

// The minimum difference to be a valid alternate path
const double SUFFICIENT_DIFFERENCE = 0.2;

Vector<Vertex*> depthFirstSearch(const BasicGraph& graph, Vertex* start, Vertex* end) {
    // TODO: implement this function; remove these comments
    //       (The function body code provided below is just a stub that returns
    //        an empty vector so that the overall project will compile.
    //        You should remove that code and replace it with your implementation.)
    (void)graph;
    (void)start;
    (void)end;
    return {};
}

Vector<Vertex*> breadthFirstSearch(const BasicGraph& graph, Vertex* start, Vertex* end) {
    // TODO: implement this function; remove these comments
    //       (The function body code provided below is just a stub that returns
    //        an empty vector so that the overall project will compile.
    //        You should remove that code and replace it with your implementation.)
    (void)graph;
    (void)start;
    (void)end;
    return {};
}

Vector<Vertex*> dijkstrasAlgorithm(const BasicGraph& graph, Vertex* start, Vertex* end) {
    // TODO: implement this function; remove these comments
    //       (The function body code provided below is just a stub that returns
    //        an empty vector so that the overall project will compile.
    //        You should remove that code and replace it with your implementation.)
    (void)graph;
    (void)start;
    (void)end;
    return {};
}

Vector<Vertex*> aStar(const BasicGraph& graph, Vertex* start, Vertex* end) {
    // TODO: implement this function; remove these comments
    //       (The function body code provided below is just a stub that returns
    //        an empty vector so that the overall project will compile.
    //        You should remove that code and replace it with your implementation.)
    (void)graph;
    (void)start;
    (void)end;
    return {};
}

Vector<Vertex*> alternatePath(const BasicGraph& graph, Vertex* start, Vertex* end) {
    // TODO: implement this function; remove these comments
    //       (The function body code provided below is just a stub that returns
    //        an empty vector so that the overall project will compile.
    //        You should remove that code and replace it with your implementation.)
    (void)graph;
    (void)start;
    (void)end;
    return {};
}
