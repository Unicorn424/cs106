#include "History.h"
#include "error.h"
using namespace std;

History::History() {
    /* TODO: Delete this line and implement this member function. */
}

History::~History() {
    /* TODO: Delete this line and implement this member function. */
}

bool History::hasNext() const {
    /* TODO: Delete this line, delete the next line, and implement this member function. */
    return false;
}

bool History::hasPrevious() const {
    /* TODO: Delete this line, delete the next line, and implement this member function. */
    return false;
}

string History::next() {
    /* TODO: Delete this line, delete the next line, and implement this member function. */
    return "";
}

string History::previous() {
    /* TODO: Delete this line, delete the next line, and implement this member function. */
    return "";
}

void History::goTo(const string& page) {
    /* TODO: Delete this line, delete the next line, and implement this member function. */
    (void) page;
}
