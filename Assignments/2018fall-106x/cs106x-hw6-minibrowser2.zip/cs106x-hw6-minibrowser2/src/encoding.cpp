// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "encoding.h"
using namespace std;

HuffmanNode* buildEncodingTree(istream& input) {
    // TODO: remove the below lines and implement this function
    (void)input;
    return nullptr;
}

void encodeData(istream& input, HuffmanNode* encodingTree, obitstream& output) {
    // TODO: remove the below lines and implement this function
    (void)input;
    (void)encodingTree;
    (void)output;
}

void decodeData(ibitstream& input, HuffmanNode* encodingTree, ostream& output) {
    // TODO: remove the below lines and implement this function
    (void)input;
    (void)encodingTree;
    (void)output;
}

void compress(istream& input, obitstream& output) {
    // TODO: remove the below lines and implement this function
    (void)input;
    (void)output;
}

void uncompress(ibitstream& input, ostream& output) {
    // TODO: remove the below lines and implement this function
    (void)input;
    (void)output;
}

void freeTree(HuffmanNode* node) {
    // TODO: remove the below lines and implement this function
    (void)node;
}
