#include "LineManager.h"
using namespace std;

LineManager::LineManager(const Vector<Line *>& lines) {
    /* TODO: Delete this line, delete the next line, and implement this member function. */
    (void) lines;
}

LineManager::~LineManager() {
    /* TODO: Delete this line and implement this member function. */
}

double LineManager::contentHeight() const {
    /* TODO: Delete this line, delete the next line, and implement this member function. */
    return 0.0;
}

Vector<Line *> LineManager::linesInRange(double lowY, double highY) const {
    /* TODO: Delete this line, delete the next three lines, and implement this member function. */
    (void) lowY;
    (void) highY;
    return {};
}

Line* LineManager::lineAt(double y) const {
    /* TODO: Delete this line, delete the next two lines, and implement this member function. */
    (void) y;
    return nullptr;
}

