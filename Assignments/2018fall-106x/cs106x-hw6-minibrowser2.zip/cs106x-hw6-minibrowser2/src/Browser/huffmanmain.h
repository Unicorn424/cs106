/**
 * CS 106B/X Huffman Encoding
 *
 * This file declares the main function that runs the Shrink-It program.
 *
 * Please do not modify this provided file. Your turned-in files should work
 * with an unmodified version of all provided code files.
 *
 * @author Nick Troccoli
 * @version 2018/11/8
 * - initial version
 */

#pragma once

void huffmanMain();
