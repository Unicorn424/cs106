#include "Autocomplete.h"
#include <cctype>

using namespace std;

Autocomplete::Autocomplete() {
    /* TODO: Delete this line and implement this function. */
}

Autocomplete::~Autocomplete() {
    /* TODO: Delete this line and implement this function. */
}

void Autocomplete::add(const string& text) {
    /* TODO: Delete this line, delete the next line, and implement this function. */
    (void) text;
}

/* Find some recommendations! */
Set<string> Autocomplete::suggestionsFor(const string& prefix, int maxHits) const {
    /* TODO: Delete this line, delete the next three lines, and implement this member function. */
    (void) prefix;
    (void) maxHits;
    return {};
}
