#include "ExpressionTests.h"
#include "Expression.h"
#include "CS106XCellModel.h"
#include "map.h"

using namespace std;
ENABLE_TESTS();

// Tests that a double expression properly stores its value
ADD_TEST("DoubleExp initialization") {
    DoubleExp e(2);
    expect(e.getValue() == 2.0);
    expect(e.toString() == "2");
}

// Tests that a double expression evaluates to its original value
ADD_TEST("DoubleExp eval") {
    Map<string, double> evalMap;  // make an empty cell map for testing
    DoubleExp e(2);
    expect(e.eval(evalMap) == 2.0);
    expect(e.getValue() == 2.0);
}

/* TODO: Add a bunch of your own custom tests here! Use this syntax:
 *
 *    ADD_TEST("Description of your test") {
 *        // code for your test
 *    }
 */
