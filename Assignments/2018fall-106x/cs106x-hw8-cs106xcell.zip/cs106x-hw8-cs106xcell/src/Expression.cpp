// This is the .cpp file that you will turn in (TODO: replace this comment!)

#include "Expression.h"
#include "error.h"
#include "strlib.h"

using namespace std;

/**
 * Implementation notes: Expression
 * --------------------------------
 * The Expression class itself implements only those methods that
 * are not designated as pure virtual.
 */
Expression::Expression()
    : rawText(""),
      value(0.0) {
    /* Empty */
}

Expression::~Expression() {
    /* Empty */
}

string Expression::getRawText() const {
    return rawText.empty() ? toString() : rawText;
}

double Expression::getValue() const {
    return value;
}

void Expression::setRawText(const string& rawText) {
    this->rawText = rawText;
}

void Expression::setValue(double value) {
    this->value = value;
}

/**
 * Implementation notes: CompoundExp
 * -------------------------------
 * The CompoundExp subclass represents an expression made up of a left and right
 * subexpression.
 */

Set<string> CompoundExp::KNOWN_OPERATORS {"+", "-", "*", "/"};

CompoundExp::CompoundExp(const string& op, Expression* lhs, Expression* rhs) {
    this->op = op;
    if (!lhs) {
        error("CompoundExp::constructor: null left sub-expression");
    }
    if (!rhs) {
        error("CompoundExp::constructor: null right sub-expression");
    }
    this->lhs = lhs;
    this->rhs = rhs;
}

CompoundExp::~CompoundExp() {
    delete lhs;
    delete rhs;
}

const Expression* CompoundExp::getLeft() const {
    return lhs;
}

string CompoundExp::getOperator() const {
    return op;
}

const Expression* CompoundExp::getRight() const {
    return rhs;
}

ExpressionType CompoundExp::getType() const {
    return COMPOUND;
}

string CompoundExp::toString() const {
    return '(' + lhs->toString() + op + rhs->toString() + ')';
}

bool CompoundExp::isFormula() const {
    return true;
}

double CompoundExp::eval(const Map<std::string, double>& cellValues) {
    (void)cellValues;
    return 0.0;
    // TODO: remove the above lines and implement this
}

/**
 * Implementation notes: DoubleExp
 * -------------------------------
 * The DoubleExp subclass represents a numeric constant.
 */
DoubleExp::DoubleExp(double value) {
    setValue(value);
}

ExpressionType DoubleExp::getType() const {
    return DOUBLE;
}

string DoubleExp::toString() const {
    return realToString(value);
}

bool DoubleExp::isFormula() const {
    return false;
}

double DoubleExp::eval(const Map<std::string, double>& cellValues) {
    (void)cellValues;
    return 0.0;
    // TODO: remove the above lines and implement this
}

/**
 * Implementation notes: IdentifierExp
 * -----------------------------------
 * The IdentifierExp subclass represents the name of another cell.
 */
IdentifierExp::IdentifierExp(const string& name) {
    this->name = name;
}

ExpressionType IdentifierExp::getType() const {
    return IDENTIFIER;
}

string IdentifierExp::toString() const {
    return name;
}

bool IdentifierExp::isFormula() const {
    return true;
}

double IdentifierExp::eval(const Map<std::string, double>& cellValues) {
    (void)cellValues;
    return 0.0;
    // TODO: remove the above lines and implement this
}

/**
 * Implementation notes: TextStringExp
 * -----------------------------------
 * The TextStringExp subclass represents a text string constant.
 */
TextStringExp::TextStringExp(const string& str) {
    this->str = str;
    setValue(0.0);
}

string TextStringExp::toString() const {
    return str;
}

ExpressionType TextStringExp::getType() const {
    return TEXTSTRING;
}

bool TextStringExp::isFormula() const {
    return false;
}

double TextStringExp::eval(const Map<std::string, double>& cellValues) {
    (void)cellValues;
    return 0.0;
    // TODO: remove the above lines and implement this
}

ostream& operator <<(ostream& out, const Expression& expr) {
    out << expr.toString();
    return out;
}
