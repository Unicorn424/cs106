// This is the .cpp file that you will turn in (TODO: replace this comment!)

#include "CS106XCellModel.h"

using namespace std;

CS106XCellModel::CS106XCellModel() {
    // TODO: implement this
}

CS106XCellModel::~CS106XCellModel() {
    // TODO: implement this
}

const Expression *CS106XCellModel::getExpressionForCell(const string& cellname) const {
    (void)cellname;
    return nullptr;
    // TODO: remove the above lines and implement this
}

void CS106XCellModel::clear() {
    // TODO: implement this
}

void CS106XCellModel::load(istream& infile) {
    (void)infile;
    // TODO: remove the above line and implement this
}

void CS106XCellModel::save(ostream& outfile) const {
    (void)outfile;
    // TODO: remove the above line and implement this
}

void CS106XCellModel::setCell(const string& cellname, const string& rawText) {
    (void)cellname;
    (void)rawText;
    // TODO: remove the above line and implement this
}
